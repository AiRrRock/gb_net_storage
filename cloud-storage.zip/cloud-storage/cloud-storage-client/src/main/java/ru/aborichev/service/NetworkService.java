package ru.aborichev.service;

public interface NetworkService {

    void sendCommand(String command);

    String readCommandResult();

    void closeConnection();

}