package ru.aborichev.factory;

import ru.aborichev.service.NetworkService;
import ru.aborichev.service.impl.IONetworkService;

public class Factory {

    public static NetworkService getNetworkService() {
        return IONetworkService.getInstance();
    }

}