package ru.aborichev.elements;

import java.io.File;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.TreeItem;

public class FileTreeItem extends TreeItem<String> {
    private boolean requestChildren = true;
    private boolean canBeLeaf = true;
    private boolean isLeaf;

    public FileTreeItem(String f) {
        super(f);
        // Handling change events on expand
        this.expandedProperty().addListener((observable, oldValue, newValue) -> requestChildren = true);
    }

    @Override
    public ObservableList<TreeItem<String>> getChildren() {
        if (requestChildren) {
            requestChildren = false;
            super.getChildren().setAll(buildChildren(this));
        }
        return super.getChildren();
    }

    @Override
    public boolean isLeaf() {
        if (canBeLeaf) {
            canBeLeaf = false;
            File f = new File(getValue());
            isLeaf = f.isFile();
        }
        return isLeaf;
    }

    private ObservableList<TreeItem<String>> buildChildren(TreeItem<String> TreeItem) {
        File f = new File(String.valueOf(TreeItem.getValue()));
        if (f.isDirectory()) {
            File[] files = f.listFiles();
            if (files != null) {
                ObservableList<TreeItem<String>> children = FXCollections
                        .observableArrayList();

                for (File childFile : files) {
                    children.add(new FileTreeItem(childFile.getAbsolutePath()));
                }

                return children;
            }
        }

        return FXCollections.emptyObservableList();
    }



}