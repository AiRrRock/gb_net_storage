package ru.aborichev.controllers;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TreeItem;
import javafx.scene.control.TreeView;
import ru.aborichev.elements.FileTreeItem;
import ru.aborichev.factory.Factory;
import ru.aborichev.service.NetworkService;


import java.io.File;
import java.net.URL;
import java.util.ResourceBundle;

public class MainController implements Initializable {

    @FXML
    TreeView<String> hostFileSystem;
    @FXML
    TreeView<File> serverFileSystem;

    private NetworkService networkService;

    public MainController() {
    }

    @FXML
    public void upload(){
        System.out.println("Uploading" + hostFileSystem.getSelectionModel().getSelectedItem().getValue() + " to " + serverFileSystem.getSelectionModel().getSelectedItem().getValue());
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        File[] roots = File.listRoots();
        TreeItem root = new TreeItem (new File("This PC"));
        for (File file : roots) {
            root.getChildren().add(new FileTreeItem(file.getAbsolutePath()));
        }
        hostFileSystem.setRoot(root);
        serverFileSystem.setRoot(root);
        networkService = Factory.getNetworkService();
        createCommandResultHandler();
    }

    private void createCommandResultHandler() {
        new Thread(() -> {
            while (true) {
                String resultCommand = networkService.readCommandResult();
                //Platform.runLater(() -> commandResultTextArea.appendText(resultCommand + System.lineSeparator()));
            }
        }).start();
    }

    public void sendCommand(ActionEvent actionEvent) {
      /*  networkService.sendCommand(commandTextField.getText().trim());
        commandTextField.clear()*/;
    }

    public void shutdown() {
   /*     networkService.closeConnection();*/
    }
}
