package ru.aborichev.providers;

import java.io.File;

public interface FSRootProvides {
    File[] getRoots();
}
