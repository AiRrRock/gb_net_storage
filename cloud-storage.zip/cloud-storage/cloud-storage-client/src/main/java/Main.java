/*
import java.io.File;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import ru.aborichev.elements.FileTreeItem;

public class Main extends Application {
    @Override
    public void start(Stage primaryStage) {
        try {
            */
/*
             * Adding a TreeView to the very left of the application window.
             *//*

            TreeView<File> fileView =
                   new TreeView<String>(
                    new FileTreeItem("C:\\"));

            */
/* Create a root node as BorderPane. *//*

            BorderPane root = new BorderPane();

            root.setCenter(fileView);


            Scene scene = new Scene(root, 800, 600);
            primaryStage.setScene(scene);
            primaryStage.setTitle("FileRex");

            */
/* Lift the curtain :0). *//*

            primaryStage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}*/
