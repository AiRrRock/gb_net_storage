import javax.swing.filechooser.FileSystemView;
import java.io.File;
import java.lang.reflect.Field;

public class Test {
    public static void main(String[] args) {
        File[] roots = File.listRoots();
        for(int i = 0; i < roots.length ; i++)
            System.out.println("Root["+i+"]:" + roots[i]);

    }
}
