package gb.cloud.server.service;

public interface ServerService {

    void startServer();

}
