package gb.cloud.server.service;

public interface ClientService {

    void startIOProcess();

}
