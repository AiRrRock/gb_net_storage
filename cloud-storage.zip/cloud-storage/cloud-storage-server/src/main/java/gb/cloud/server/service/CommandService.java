package gb.cloud.server.service;

public interface CommandService {

    String processCommand(String command);

    String getCommand();

}
