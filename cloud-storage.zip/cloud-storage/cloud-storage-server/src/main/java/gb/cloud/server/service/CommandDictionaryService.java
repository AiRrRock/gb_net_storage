package gb.cloud.server.service;

public interface CommandDictionaryService {

    String processCommand(String command);

}
